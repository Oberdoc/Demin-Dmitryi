#include "Form2.h"
#include "Form3.h"

#pragma once

namespace PasswordManager {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Runtime::InteropServices;
	using namespace System::IO;

	/// <summary>
	/// ������ ��� Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
			listView1->Enabled = false;
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox3;
	protected: 
	private: System::Windows::Forms::TextBox^  textBox7;
	private: System::Windows::Forms::Button^  button4;
	internal: System::Windows::Forms::ListView^  listView1;
	private: 
	private: System::Windows::Forms::ColumnHeader^  columnHeader1;
	internal: 
	private: System::Windows::Forms::ColumnHeader^  columnHeader2;
	private: System::Windows::Forms::ColumnHeader^  columnHeader3;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::TextBox^  textBox6;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  �������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  �������ToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  �������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
	private: System::Windows::Forms::ToolStripMenuItem^  �����ToolStripMenuItem1;

	private: System::Windows::Forms::ToolStripMenuItem^  ����������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  �������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
	private: System::Windows::Forms::ToolStripMenuItem^  ����������ToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem1;
	private: System::Windows::Forms::CheckBox^  checkBox1;




	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->listView1 = (gcnew System::Windows::Forms::ListView());
			this->columnHeader1 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader2 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader3 = (gcnew System::Windows::Forms::ColumnHeader());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->�������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�������ToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->�����ToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->����������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->����������ToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->groupBox3->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->textBox7);
			this->groupBox3->Controls->Add(this->button4);
			this->groupBox3->Location = System::Drawing::Point(121, 91);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(210, 100);
			this->groupBox3->TabIndex = 18;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"������� ������-������:";
			this->groupBox3->Visible = false;
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(54, 31);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(100, 20);
			this->textBox7->TabIndex = 1;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(54, 57);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(100, 23);
			this->button4->TabIndex = 0;
			this->button4->Text = L"��";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click_1);
			// 
			// listView1
			// 
			this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(3) {this->columnHeader1, this->columnHeader2, 
				this->columnHeader3});
			this->listView1->Dock = System::Windows::Forms::DockStyle::Top;
			this->listView1->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->listView1->Location = System::Drawing::Point(0, 0);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(444, 220);
			this->listView1->TabIndex = 17;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			this->listView1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::listView1_SelectedIndexChanged);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = L"������";
			this->columnHeader1->Width = 203;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = L"�����";
			this->columnHeader2->Width = 116;
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = L"������";
			this->columnHeader3->Width = 120;
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->button3);
			this->groupBox2->Controls->Add(this->textBox4);
			this->groupBox2->Controls->Add(this->textBox5);
			this->groupBox2->Controls->Add(this->textBox6);
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Controls->Add(this->label5);
			this->groupBox2->Controls->Add(this->label6);
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Enabled = false;
			this->groupBox2->Location = System::Drawing::Point(232, 258);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(200, 148);
			this->groupBox2->TabIndex = 16;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"������������� ������ :";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(134, 106);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(60, 23);
			this->button3->TabIndex = 12;
			this->button3->Text = L"�������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(69, 57);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(125, 20);
			this->textBox4->TabIndex = 11;
			this->textBox4->UseSystemPasswordChar = true;
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(69, 35);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(125, 20);
			this->textBox5->TabIndex = 10;
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(69, 13);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(125, 20);
			this->textBox6->TabIndex = 9;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(6, 59);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(48, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"������:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(6, 38);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(41, 13);
			this->label5->TabIndex = 7;
			this->label5->Text = L"�����:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(6, 16);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(47, 13);
			this->label6->TabIndex = 6;
			this->label6->Text = L"������:";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(34, 106);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(94, 23);
			this->button2->TabIndex = 5;
			this->button2->Text = L"�������������";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->checkBox1);
			this->groupBox1->Controls->Add(this->textBox3);
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Enabled = false;
			this->groupBox1->Location = System::Drawing::Point(12, 258);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(200, 142);
			this->groupBox1->TabIndex = 15;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"�������� ������ :";
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(9, 83);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(127, 17);
			this->checkBox1->TabIndex = 12;
			this->checkBox1->Text = L"���������� ������";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Form1::checkBox1_CheckedChanged);
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(59, 57);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(135, 20);
			this->textBox3->TabIndex = 11;
			this->textBox3->UseSystemPasswordChar = true;
			this->textBox3->Click += gcnew System::EventHandler(this, &Form1::textBox3_Click);
			this->textBox3->TextChanged += gcnew System::EventHandler(this, &Form1::textBox3_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(59, 35);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(135, 20);
			this->textBox2->TabIndex = 10;
			this->textBox2->Click += gcnew System::EventHandler(this, &Form1::textBox2_Click);
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(59, 13);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(135, 20);
			this->textBox1->TabIndex = 9;
			this->textBox1->Click += gcnew System::EventHandler(this, &Form1::textBox1_Click);
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(6, 59);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(48, 13);
			this->label3->TabIndex = 8;
			this->label3->Text = L"������:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(6, 38);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(41, 13);
			this->label2->TabIndex = 7;
			this->label2->Text = L"�����:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(6, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(47, 13);
			this->label1->TabIndex = 6;
			this->label1->Text = L"������:";
			// 
			// button1
			// 
			this->button1->Enabled = false;
			this->button1->Location = System::Drawing::Point(59, 106);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(76, 23);
			this->button1->TabIndex = 5;
			this->button1->Text = L"��";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(33, 33);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->�������ToolStripMenuItem, 
				this->����������ToolStripMenuItem, this->toolStripMenuItem1});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(444, 24);
			this->menuStrip1->TabIndex = 14;
			this->menuStrip1->Text = L"menuStrip1";
			this->menuStrip1->Visible = false;
			// 
			// �������ToolStripMenuItem
			// 
			this->�������ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->�������ToolStripMenuItem1, 
				this->�������ToolStripMenuItem, this->toolStripSeparator1, this->�����ToolStripMenuItem1});
			this->�������ToolStripMenuItem->Name = L"�������ToolStripMenuItem";
			this->�������ToolStripMenuItem->Size = System::Drawing::Size(45, 20);
			this->�������ToolStripMenuItem->Text = L"����";
			// 
			// �������ToolStripMenuItem1
			// 
			this->�������ToolStripMenuItem1->Name = L"�������ToolStripMenuItem1";
			this->�������ToolStripMenuItem1->Size = System::Drawing::Size(120, 22);
			this->�������ToolStripMenuItem1->Text = L"�������";
			this->�������ToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::�������ToolStripMenuItem1_Click);
			// 
			// �������ToolStripMenuItem
			// 
			this->�������ToolStripMenuItem->Enabled = false;
			this->�������ToolStripMenuItem->Name = L"�������ToolStripMenuItem";
			this->�������ToolStripMenuItem->Size = System::Drawing::Size(120, 22);
			this->�������ToolStripMenuItem->Text = L"�������";
			this->�������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::�������ToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(117, 6);
			// 
			// �����ToolStripMenuItem1
			// 
			this->�����ToolStripMenuItem1->Name = L"�����ToolStripMenuItem1";
			this->�����ToolStripMenuItem1->Size = System::Drawing::Size(120, 22);
			this->�����ToolStripMenuItem1->Text = L"�����";
			this->�����ToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::�����ToolStripMenuItem1_Click);
			// 
			// ����������ToolStripMenuItem
			// 
			this->����������ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->�������ToolStripMenuItem, 
				this->toolStripSeparator2, this->����������ToolStripMenuItem1});
			this->����������ToolStripMenuItem->Name = L"����������ToolStripMenuItem";
			this->����������ToolStripMenuItem->Size = System::Drawing::Size(62, 20);
			this->����������ToolStripMenuItem->Text = L"�������";
			// 
			// �������ToolStripMenuItem
			// 
			this->�������ToolStripMenuItem->Name = L"�������ToolStripMenuItem";
			this->�������ToolStripMenuItem->Size = System::Drawing::Size(138, 22);
			this->�������ToolStripMenuItem->Text = L"�������";
			this->�������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::�������ToolStripMenuItem_Click);
			// 
			// toolStripSeparator2
			// 
			this->toolStripSeparator2->Name = L"toolStripSeparator2";
			this->toolStripSeparator2->Size = System::Drawing::Size(135, 6);
			// 
			// ����������ToolStripMenuItem1
			// 
			this->����������ToolStripMenuItem1->Name = L"����������ToolStripMenuItem1";
			this->����������ToolStripMenuItem1->Size = System::Drawing::Size(138, 22);
			this->����������ToolStripMenuItem1->Text = L"� ���������";
			this->����������ToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::����������ToolStripMenuItem1_Click);
			// 
			// toolStripMenuItem1
			// 
			this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
			this->toolStripMenuItem1->Size = System::Drawing::Size(12, 20);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(444, 418);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->listView1);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Password Manager";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Click += gcnew System::EventHandler(this, &Form1::Form1_Click);
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private:
	String^ ser; //�������� �������
	String^ log; //�����
	String^ pas; //������ 
	bool nf;     //��������� �������� �����, �� ��������� ����
	bool pp;     //������ ������
	bool bz;     //��� ������
	int n;       //���������� �������
	int delrec;  //����� ������, �������������� � ��������
	int edrec;   //����� ������, �������������� � ��������������
	char* nName; 
	char* Password;
	char* Result;

String^ CharToSystemString(char* ch) 
{
	return gcnew String(ch);
}

char* SystemStringToChar(System::String^ string) 
{
	return (char*)(void*)Marshal::StringToHGlobalAnsi(string);
}

//�����������/�������������
void code(char* lpName, char* lpPassword, char* lpResult)
{
    unsigned int a = 0, b = 0;
    a = 0;

    while (lpResult[a])
    {
        b = 0;

        while (lpPassword[b]) 
        {
// �������� ������� XOR'�� 
            lpResult[a] ^= (lpPassword[b] + (a*b)); 
            b++; 
        }
        a++; 
    }
}

//���� �����������
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) 
{
	if (!(File::Exists(Application::StartupPath + "\\data.pk")))
		�������ToolStripMenuItem1->Text = "�������";

	listView1->Visible = false;
	groupBox1->Visible = false;
	groupBox2->Visible = false;
	groupBox3->Visible = true;

	listView1->Clear();

	textBox7->Focus();
}

//������� �������
void ClearTable()
{
	int i;
	for(i=0; i<listView1->Items->Count; i++) listView1->Items[i]->Remove();
}

//������� �������� ������ 2 � �� �������������
void pan2notenabled()
{
	textBox6->Text = "";
	textBox5->Text = "";
	textBox4->Text = "";
	groupBox2->Enabled = false;
}

//����� ������ - ��
private: System::Void button4_Click_1(System::Object^  sender, System::EventArgs^  e) 
{
	if (!(textBox7->Text == ""))
	{
		pas = textBox7->Text;

		listView1->Visible = true;
		groupBox1->Visible = true;
		groupBox2->Visible = true;
		groupBox3->Visible = false;

		menuStrip1->Visible = true;
	}
}

private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) 
{
	
}

//���������� � ����
void save() 
{
	System::IO::StreamWriter^ sw; //����� ��� ������

	sw = gcnew System::IO::StreamWriter(
		Application::StartupPath + "\\data.pk");


	//���������� ���������� �������
	Result = SystemStringToChar(listView1->Items->Count.ToString());
	code(SystemStringToChar(listView1->Items->Count.ToString()), SystemStringToChar(pas), Result);
	sw->WriteLine(CharToSystemString(Result));
	/*
	//��������� ������-������
	Result = SystemStringToChar(pas);
	code(SystemStringToChar(pas), SystemStringToChar(pas), Result);
	sw->WriteLine(CharToSystemString(Result));
	*/
	//��������� ��� ������
	int i;
	for(i=0; i<listView1->Items->Count; i++)
	{
		Result = SystemStringToChar(listView1->Items[i]->Text);
		code(SystemStringToChar(listView1->Items[i]->Text), SystemStringToChar(pas), Result);
		sw->WriteLine(CharToSystemString(Result));

		Result = SystemStringToChar(listView1->Items[i]->SubItems[1]->Text);
		code(SystemStringToChar(listView1->Items[i]->SubItems[1]->Text), SystemStringToChar(pas), Result);
		sw->WriteLine(CharToSystemString(Result));

		Result = SystemStringToChar(listView1->Items[i]->SubItems[2]->Text);
		code(SystemStringToChar(listView1->Items[i]->SubItems[2]->Text), SystemStringToChar(pas), Result);
		sw->WriteLine(CharToSystemString(Result));
	}
	
	sw->Close();		
}

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	//���� �������
	nf = true;

	//������� ����� �������
	n = listView1->Items->Count;

	//���� �����
	listView1->Items->Add(textBox1->Text);
	listView1->Items[n]->SubItems->Add(textBox2->Text);
	listView1->Items[n]->SubItems->Add(textBox3->Text); 
	n++;

	//������ ���������
	textBox1->Text = "";
	textBox2->Text = "";
	textBox3->Text = "";
	button1->Enabled = false;
}

private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) 
{
	if ((textBox2->Text != "") && (textBox3->Text != "")) 
		button1->Enabled = true;
	else button1->Enabled = false;
	pan2notenabled();
}

private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) 
{
	if ((textBox1->Text != "") && (textBox3->Text != "")) 
		button1->Enabled = true;
	else button1->Enabled = false;
	pan2notenabled();
}

private: System::Void textBox3_TextChanged(System::Object^  sender, System::EventArgs^  e) 
{
	if ((textBox2->Text != "") && (textBox1->Text != "")) 
		button1->Enabled = true;
	else button1->Enabled = false;
	pan2notenabled();
}

//������� �������
private: System::Void listView1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) 
{
	groupBox2->Enabled = true;
	
	delrec = listView1->FocusedItem->Index;
	edrec = listView1->FocusedItem->Index;
	textBox6->Text = listView1->FocusedItem->Text;
	textBox5->Text = listView1->FocusedItem->SubItems[1]->Text;
	textBox4->Text = listView1->FocusedItem->SubItems[2]->Text;
}


//������� ��������
void OpenFile()
{
	listView1->Enabled = true;
	groupBox1->Enabled = true;

	if (bz)
	{
		this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(3) {this->columnHeader1, this->columnHeader2, 
				this->columnHeader3});
			this->listView1->Dock = System::Windows::Forms::DockStyle::Top;
			this->listView1->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->listView1->Location = System::Drawing::Point(0, 24);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(444, 220);
			this->listView1->TabIndex = 17;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			this->listView1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::listView1_SelectedIndexChanged);

			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = L"������";
			this->columnHeader1->Width = 125;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = L"�����";
			this->columnHeader2->Width = 116;
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = L"������";
			this->columnHeader3->Width = 116;
			

			bz = false;
	}

	int i;
	for(i=0; i<listView1->Items->Count; i++) listView1->Items[i]->Remove();

	System::IO::StreamReader^ sr; //����� ��� ������

	sr = gcnew System::IO::StreamReader(
		Application::StartupPath + "\\data.pk");

	String^ t;

	//��������� ���������� �������
	t = sr->ReadLine();
	Result = SystemStringToChar(t);
	code(Result, SystemStringToChar(pas), Result);
	n = System::Convert::ToInt32(CharToSystemString(Result));

	/*//��������� ������-������
	t = sr->ReadLine();
	Result = SystemStringToChar(t);
	code(Result, SystemStringToChar(pas), Result);
	pas = CharToSystemString(Result);*/

	for(i=0; i<n; i++)
	{
		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(SystemStringToChar(t), SystemStringToChar(pas), Result);
		listView1->Items->Add(CharToSystemString(Result));
		
		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(SystemStringToChar(t), SystemStringToChar(pas), Result);
		listView1->Items[i]->SubItems->Add(CharToSystemString(Result));

		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(SystemStringToChar(t), SystemStringToChar(pas), Result);
		listView1->Items[i]->SubItems->Add(CharToSystemString(Result));

	}

/*	int i;
	for(i=0; i<n*3; i++)
	{
		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(Result, SystemStringToChar(pas), Result);
		listView1->Items[i]->Text = CharToSystemString(Result);

		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(Result, SystemStringToChar(pas), Result);
		listView1->Items[i]->SubItems[1]->Text = CharToSystemString(Result);

		t = sr->ReadLine();
		Result = SystemStringToChar(t);
		code(Result, SystemStringToChar(pas), Result);
		listView1->Items[i]->SubItems[2]->Text = CharToSystemString(Result);
	}*/

	sr->Close();
}

//�������
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
{
	listView1->Items[delrec]->Remove();
	textBox6->Text = "";
	textBox5->Text = "";
	textBox4->Text = "";
	groupBox2->Enabled = false;
}

//�������������
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
{
	listView1->Items[edrec]->Text = textBox6->Text;
	listView1->Items[edrec]->SubItems[1]->Text = textBox5->Text;
	listView1->Items[edrec]->SubItems[2]->Text = textBox4->Text;
}

private: System::Void Form1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	pan2notenabled();
}

private: System::Void textBox1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	pan2notenabled();
}

private: System::Void textBox2_Click(System::Object^  sender, System::EventArgs^  e) 
{
	pan2notenabled();
}

private: System::Void textBox3_Click(System::Object^  sender, System::EventArgs^  e) 
{
	pan2notenabled();
}

private: System::Void �������ToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(3) {this->columnHeader1, this->columnHeader2, 
				this->columnHeader3});
			this->listView1->Dock = System::Windows::Forms::DockStyle::Top;
			this->listView1->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->listView1->Location = System::Drawing::Point(0, 24);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(444, 220);
			this->listView1->TabIndex = 17;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			this->listView1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::listView1_SelectedIndexChanged);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = L"������";
			this->columnHeader1->Width = 125;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = L"�����";
			this->columnHeader2->Width = 116;
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = L"������";
			this->columnHeader3->Width = 116;

			bz = false;

	groupBox1->Enabled = true;
	listView1->Enabled = true;

	�������ToolStripMenuItem->Enabled = true;

	if (File::Exists(Application::StartupPath + "\\data.pk"))
		OpenFile();
}

private: System::Void �������ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) 
{
	�������ToolStripMenuItem->Enabled = false;

	if (listView1->Items->Count >= 0) save();
	groupBox1->Enabled = false;
	//int i;

	//for(i=0; i<listView1->Items->Count; i++) listView1->Items[i]->Remove();
	listView1->Enabled = false;

	pan2notenabled();
	�������ToolStripMenuItem1->Text = "�������";

	listView1->Clear();

	bz = true;
}

//�����
private: System::Void �����ToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	if (listView1->Items->Count >= 0) save();
	this->Close();
}



private: System::Void �������ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Form2^ spr = gcnew Form2();
	spr->ShowDialog();
}
private: System::Void ����������ToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Form3^ ab = gcnew Form3();
	ab->ShowDialog();
}
private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(checkBox1->Checked==false){
			 textBox3->UseSystemPasswordChar=true;
			 textBox4->UseSystemPasswordChar=true;
			 } else {
			 textBox3->UseSystemPasswordChar=false;
			 textBox4->UseSystemPasswordChar=false;
			 }
		 }
};
}
